/**
 * Helper function to format analysis text with bullet points
 * @param {string} analysisText - The analysis text from the API
 * @returns {string} - Formatted HTML
 */
function formatAnalysis(analysisText) {
    if (!analysisText) return 'No analysis available';
    
    // Handle bullet points (common in AI responses)
    let formattedText = analysisText
        .replace(/\n/g, '<br>')
        .replace(/• /g, '<li>')
        .replace(/\* /g, '<li>')
        .replace(/- /g, '<li>')
        .replace(/<li>/g, '</li><li>');
    
    // If we detected bullet points, wrap in ul tags
    if (formattedText.includes('<li>')) {
        formattedText = '<ul class="mb-0">' + formattedText + '</li></ul>';
        formattedText = formattedText.replace('<li></li>', ''); // Remove empty first item
    }
    
    return formattedText;
}

/**
 * Market Data Module
 * Handles real-time market data fetching and display
 */
class MarketDataManager {
    constructor() {
        this.symbols = new Set();
        this.activeSymbol = null;
        this.updateInterval = null;
        this.updateFrequency = 5000; // Update every 5 seconds by default
        this.isUpdating = false;
        
        // DOM Elements
        this.symbolInput = document.getElementById('symbol-input');
        this.addSymbolBtn = document.getElementById('add-symbol-btn');
        this.symbolsContainer = document.getElementById('monitored-symbols');
        this.marketDataContainer = document.getElementById('market-data-container');
        this.level2Container = document.getElementById('level2-container');
        this.timeAndSalesContainer = document.getElementById('time-and-sales-container');
        this.updateFrequencySelect = document.getElementById('update-frequency');
        this.autoUpdateToggle = document.getElementById('auto-update-toggle');
        
        this.initEventListeners();
    }
    
    /**
     * Initialize event listeners
     */
    initEventListeners() {
        // Add symbol button
        if (this.addSymbolBtn && this.symbolInput) {
            this.addSymbolBtn.addEventListener('click', () => {
                this.addSymbol(this.symbolInput.value);
            });
            
            // Allow adding by pressing Enter
            this.symbolInput.addEventListener('keyup', (e) => {
                if (e.key === 'Enter') {
                    this.addSymbol(this.symbolInput.value);
                }
            });
        }
        
        // Update frequency select
        if (this.updateFrequencySelect) {
            this.updateFrequencySelect.addEventListener('change', () => {
                this.updateFrequency = parseInt(this.updateFrequencySelect.value);
                
                // Restart the update interval if auto-update is enabled
                if (this.updateInterval) {
                    this.stopAutoUpdate();
                    this.startAutoUpdate();
                }
            });
        }
        
        // Auto-update toggle
        if (this.autoUpdateToggle) {
            this.autoUpdateToggle.addEventListener('change', () => {
                if (this.autoUpdateToggle.checked) {
                    this.startAutoUpdate();
                } else {
                    this.stopAutoUpdate();
                }
            });
        }
    }
    
    /**
     * Add a symbol to monitor
     * @param {string} symbol - The stock symbol to add
     */
    addSymbol(symbol) {
        if (!symbol) return;
        
        symbol = symbol.toUpperCase().trim();
        
        if (this.symbols.has(symbol)) {
            this.setActiveSymbol(symbol);
            return;
        }
        
        // Show loading state
        this.showLoadingState();
        
        // Call API to add symbol
        fetch('/market/monitor', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ symbol })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Add to local set
                this.symbols.add(symbol);
                
                // Clear input
                this.symbolInput.value = '';
                
                // Update UI
                this.updateSymbolList();
                this.setActiveSymbol(symbol);
                
                // Show success message
                this.showToast(`Added ${symbol} to monitoring`);
            } else {
                // Show error
                this.showError(data.error || `Failed to add ${symbol}`);
            }
        })
        .catch(error => {
            console.error('Error adding symbol:', error);
            this.showError(`Failed to add ${symbol}: ${error.message}`);
        });
    }
    
    /**
     * Remove a symbol from monitoring
     * @param {string} symbol - The stock symbol to remove
     */
    removeSymbol(symbol) {
        if (!symbol || !this.symbols.has(symbol)) return;
        
        // Call API to remove symbol
        fetch(`/market/monitor/${symbol}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Remove from local set
                this.symbols.delete(symbol);
                
                // Update UI
                this.updateSymbolList();
                
                // If this was the active symbol, clear the data display
                if (this.activeSymbol === symbol) {
                    this.activeSymbol = null;
                    this.clearDataDisplay();
                    
                    // Set another symbol as active if available
                    if (this.symbols.size > 0) {
                        this.setActiveSymbol([...this.symbols][0]);
                    }
                }
                
                // Show success message
                this.showToast(`Removed ${symbol} from monitoring`);
            } else {
                // Show error
                this.showError(data.error || `Failed to remove ${symbol}`);
            }
        })
        .catch(error => {
            console.error('Error removing symbol:', error);
            this.showError(`Failed to remove ${symbol}: ${error.message}`);
        });
    }
    
    /**
     * Load the list of currently monitored symbols
     */
    loadMonitoredSymbols() {
        fetch('/market/monitor')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Clear existing symbols
                this.symbols.clear();
                
                // Add each symbol
                data.symbols.forEach(symbol => this.symbols.add(symbol));
                
                // Update UI
                this.updateSymbolList();
                
                // Set first symbol as active if we don't have an active symbol
                if (data.symbols.length > 0 && !this.activeSymbol) {
                    this.setActiveSymbol(data.symbols[0]);
                }
            } else {
                this.showError('Failed to load monitored symbols');
            }
        })
        .catch(error => {
            console.error('Error loading symbols:', error);
            this.showError(`Failed to load symbols: ${error.message}`);
        });
    }
    
    /**
     * Update the UI list of monitored symbols
     */
    updateSymbolList() {
        if (!this.symbolsContainer) return;
        
        if (this.symbols.size === 0) {
            this.symbolsContainer.innerHTML = `
                <div class="alert alert-info">
                    No symbols are being monitored. Add a symbol to get started.
                </div>
            `;
            return;
        }
        
        let html = '<div class="list-group">';
        
        // Add each symbol
        this.symbols.forEach(symbol => {
            const isActive = symbol === this.activeSymbol;
            html += `
                <div class="list-group-item list-group-item-action d-flex justify-content-between align-items-center ${isActive ? 'active' : ''}">
                    <span class="symbol-name" data-symbol="${symbol}" style="cursor: pointer;">${symbol}</span>
                    <button class="btn btn-sm ${isActive ? 'btn-light' : 'btn-danger'} remove-symbol" data-symbol="${symbol}">
                        <i class="bi bi-x"></i>
                    </button>
                </div>
            `;
        });
        
        html += '</div>';
        this.symbolsContainer.innerHTML = html;
        
        // Add event listeners to symbol names
        document.querySelectorAll('.symbol-name').forEach(element => {
            element.addEventListener('click', () => {
                const symbol = element.getAttribute('data-symbol');
                this.setActiveSymbol(symbol);
            });
        });
        
        // Add event listeners to remove buttons
        document.querySelectorAll('.remove-symbol').forEach(button => {
            button.addEventListener('click', (e) => {
                e.stopPropagation();
                const symbol = button.getAttribute('data-symbol');
                this.removeSymbol(symbol);
            });
        });
    }
    
    /**
     * Set a symbol as active and load its data
     * @param {string} symbol - The stock symbol to set as active
     */
    setActiveSymbol(symbol) {
        if (!symbol) return;
        
        this.activeSymbol = symbol;
        this.updateSymbolList();
        this.loadSymbolData(symbol);
    }
    
    /**
     * Load market data for a specific symbol
     * @param {string} symbol - The stock symbol to load data for
     */
    loadSymbolData(symbol) {
        if (!symbol) return;
        
        this.showLoadingState();
        
        // Fetch market data
        fetch(`/market/data/${symbol}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.displayMarketData(data);
            } else {
                this.showError(data.error || `Failed to load data for ${symbol}`);
            }
        })
        .catch(error => {
            console.error(`Error loading market data for ${symbol}:`, error);
            this.showError(`Failed to load market data: ${error.message}`);
        });
        
        // Fetch Level 2 data
        fetch(`/market/level2/${symbol}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.displayLevel2Data(data);
            } else {
                console.error('Level 2 data error:', data.error);
            }
        })
        .catch(error => {
            console.error(`Error loading Level 2 data for ${symbol}:`, error);
        });
        
        // Fetch Time & Sales data
        fetch(`/market/time-and-sales/${symbol}?limit=30`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.displayTimeAndSalesData(data);
            } else {
                console.error('Time & Sales data error:', data.error);
            }
        })
        .catch(error => {
            console.error(`Error loading Time & Sales for ${symbol}:`, error);
        });
    }
    
    /**
     * Display market data in the UI
     * @param {Object} data - Market data response from the API
     */
    displayMarketData(data) {
        if (!this.marketDataContainer) return;
        
        const marketData = data.market_data;
        if (!marketData) {
            this.marketDataContainer.innerHTML = `
                <div class="alert alert-warning">
                    No market data available for ${data.symbol}
                </div>
            `;
            return;
        }
        
        // Format the display
        this.marketDataContainer.innerHTML = `
            <div class="card mb-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">${data.symbol} - Market Data</h5>
                    <span class="badge bg-info">${new Date(marketData.timestamp).toLocaleTimeString()}</span>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-sm">
                                <tr>
                                    <th>Bid:</th>
                                    <td class="bid-price">${marketData.bid_price ? '$' + marketData.bid_price.toFixed(2) : 'N/A'}</td>
                                    <td class="bid-size">${marketData.bid_size || 'N/A'}</td>
                                </tr>
                                <tr>
                                    <th>Ask:</th>
                                    <td class="ask-price">${marketData.ask_price ? '$' + marketData.ask_price.toFixed(2) : 'N/A'}</td>
                                    <td class="ask-size">${marketData.ask_size || 'N/A'}</td>
                                </tr>
                                <tr>
                                    <th>Spread:</th>
                                    <td colspan="2" class="spread">${marketData.spread ? '$' + marketData.spread.toFixed(4) : 'N/A'}</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-sm">
                                <tr>
                                    <th>Last:</th>
                                    <td class="last-price">${marketData.last_price ? '$' + marketData.last_price.toFixed(2) : 'N/A'}</td>
                                </tr>
                                <tr>
                                    <th>Volume:</th>
                                    <td class="volume">${marketData.volume ? marketData.volume.toLocaleString() : 'N/A'}</td>
                                </tr>
                                <tr>
                                    <th>VWAP:</th>
                                    <td class="vwap">${marketData.vwap ? '$' + marketData.vwap.toFixed(2) : 'N/A'}</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Load analysis data
        this.loadAnalysisData(data.symbol);
    }
    
    /**
     * Display Level 2 order book data
     * @param {Object} data - Level 2 data response from API
     */
    displayLevel2Data(data) {
        if (!this.level2Container) return;
        
        if (!data.data || data.data.length === 0) {
            this.level2Container.innerHTML = `
                <div class="alert alert-warning">
                    No Level 2 data available for ${data.symbol}
                </div>
            `;
            return;
        }
        
        let html = `
            <div class="card mb-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">${data.symbol} - Order Book</h5>
                    <span class="badge bg-info">${new Date(data.timestamp).toLocaleTimeString()}</span>
                </div>
                <div class="card-body p-0">
                    <div class="level2-note p-2 bg-light border-bottom">
                        <small class="text-muted">${data.note || 'Order book data showing price levels and sizes'}</small>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>Price</th>
                                    <th>Size</th>
                                    <th>Exchange</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
        `;
        
        // Process the trades into a format similar to Level 2 data
        const priceMap = new Map();
        
        // Group by price
        data.data.forEach(trade => {
            const price = trade.p;
            const size = trade.s;
            
            if (!priceMap.has(price)) {
                priceMap.set(price, {
                    price: price,
                    size: size,
                    exchange: trade.x,
                    time: new Date(trade.t / 1000000).toLocaleTimeString(),
                    count: 1
                });
            } else {
                const existing = priceMap.get(price);
                existing.size += size;
                existing.count += 1;
            }
        });
        
        // Sort by price (descending)
        const sortedPrices = [...priceMap.entries()]
            .sort((a, b) => b[0] - a[0])
            .map(entry => entry[1]);
        
        // Add table rows
        sortedPrices.forEach(level => {
            html += `
                <tr>
                    <td>$${level.price.toFixed(2)}</td>
                    <td>${level.size}</td>
                    <td>${level.exchange || 'N/A'}</td>
                    <td>${level.time}</td>
                </tr>
            `;
        });
        
        html += `
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
        
        this.level2Container.innerHTML = html;
    }
    
    /**
     * Display Time & Sales data (recent trades)
     * @param {Object} data - Time & Sales data response from API
     */
    displayTimeAndSalesData(data) {
        if (!this.timeAndSalesContainer) return;
        
        if (!data.trades || data.trades.length === 0) {
            this.timeAndSalesContainer.innerHTML = `
                <div class="alert alert-warning">
                    No Time & Sales data available for ${data.symbol}
                </div>
            `;
            return;
        }
        
        let html = `
            <div class="card mb-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">${data.symbol} - Time & Sales</h5>
                    <span class="badge bg-info">${data.trades.length} Trades</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
                        <table class="table table-sm table-striped table-hover mb-0">
                            <thead class="sticky-top bg-dark">
                                <tr>
                                    <th>Time</th>
                                    <th>Price</th>
                                    <th>Size</th>
                                    <th>Exchange</th>
                                </tr>
                            </thead>
                            <tbody>
        `;
        
        // Add table rows
        data.trades.forEach(trade => {
            const tradeTime = new Date(trade.timestamp);
            
            // Determine if trade was a buy or sell (if available)
            let rowClass = '';
            if (trade.is_buyer_maker === false) {
                rowClass = 'table-success'; // Buy (green)
            } else if (trade.is_buyer_maker === true) {
                rowClass = 'table-danger'; // Sell (red)
            }
            
            html += `
                <tr class="${rowClass}">
                    <td>${tradeTime.toLocaleTimeString()}</td>
                    <td>$${trade.price.toFixed(2)}</td>
                    <td>${trade.size}</td>
                    <td>${trade.exchange || 'N/A'}</td>
                </tr>
            `;
        });
        
        html += `
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
        
        this.timeAndSalesContainer.innerHTML = html;
    }
    
    /**
     * Load and display trading analysis for a symbol
     * @param {string} symbol - The stock symbol to analyze
     */
    loadAnalysisData(symbol, useAI = true) {
        if (!symbol) return;
        
        // Get the analysis depth from the UI if available
        const analysisDepthSelect = document.getElementById('analysis-depth');
        const analysisDepth = analysisDepthSelect ? analysisDepthSelect.value : 'standard';
        
        // Decide which endpoint to use based on useAI flag
        const endpoint = useAI ? 
            `/market/ai-analysis/${symbol}?depth=${analysisDepth}` : 
            `/market/analysis/${symbol}?use_ai=false`;
            
        fetch(endpoint)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.displayAnalysisData(data);
            } else {
                console.error('Analysis error:', data.error);
            }
        })
        .catch(error => {
            console.error(`Error loading ${useAI ? 'AI' : 'standard'} analysis for ${symbol}:`, error);
        });
    }
    
    /**
     * Display trading analysis data
     * @param {Object} data - Analysis data response from API
     */
    displayAnalysisData(data) {
        if (!this.marketDataContainer) return;
        
        // Find or create the analysis section
        let analysisSection = document.getElementById('analysis-section');
        if (!analysisSection) {
            analysisSection = document.createElement('div');
            analysisSection.id = 'analysis-section';
            this.marketDataContainer.appendChild(analysisSection);
        }
        
        // Determine recommendation class
        let recommendationClass = 'secondary';
        if (data.recommendation) {
            switch (data.recommendation.toLowerCase()) {
                case 'enter':
                    recommendationClass = 'success';
                    break;
                case 'exit':
                    recommendationClass = 'danger';
                    break;
                case 'hold':
                    recommendationClass = 'warning';
                    break;
                case 'wait':
                    recommendationClass = 'info';
                    break;
            }
        }
        
        // Format the display - different layout for AI vs standard analysis
        let contentHtml = '';
        
        // Check if this is AI analysis
        if (data.ai_analysis || data.analysis) {
            // AI/Detailed analysis layout
            contentHtml = `
                <div class="card mb-3">
                    <div class="card-header d-flex justify-content-between align-items-center bg-dark text-light">
                        <h5 class="mb-0">${data.ai_analysis ? 'AI-Powered' : ''} Trading Analysis</h5>
                        <div>
                            <span class="badge bg-${recommendationClass} me-2">${data.recommendation || 'N/A'}</span>
                            ${data.risk_level ? `<span class="badge bg-secondary">Risk: ${data.risk_level}</span>` : ''}
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-12">
                                <h6>Analysis:</h6>
                                <div class="p-3 rounded border">
                                    ${data.analysis ? formatAnalysis(data.analysis) : 'No analysis available'}
                                </div>
                                ${data.reason ? `
                                <div class="mt-2">
                                    <strong>Reason:</strong> ${data.reason}
                                </div>` : ''}
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Market Conditions:</h6>
                                <table class="table table-sm">
                                    <tr>
                                        <th style="width: 40%">Current Price:</th>
                                        <td>${data.current_price ? '$' + data.current_price : 'N/A'}</td>
                                    </tr>
                                    <tr>
                                        <th>Bid Price:</th>
                                        <td>${data.bid_price ? '$' + data.bid_price : 'N/A'}</td>
                                    </tr>
                                    <tr>
                                        <th>Ask Price:</th>
                                        <td>${data.ask_price ? '$' + data.ask_price : 'N/A'}</td>
                                    </tr>
                                    <tr>
                                        <th>Spread:</th>
                                        <td>${data.spread ? '$' + data.spread : 'N/A'}</td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <h6>Momentum Indicators:</h6>
                                <table class="table table-sm">
                                    <tr>
                                        <th style="width: 40%">Buying Pressure:</th>
                                        <td>
                                            <div class="progress">
                                                <div class="progress-bar bg-success" style="width: ${data.buying_pressure || 0}%">
                                                    ${data.buying_pressure || 0}%
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Selling Pressure:</th>
                                        <td>
                                            <div class="progress">
                                                <div class="progress-bar bg-danger" style="width: ${data.selling_pressure || 0}%">
                                                    ${data.selling_pressure || 0}%
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Trades/Min:</th>
                                        <td>${data.trades_per_minute || 'N/A'}</td>
                                    </tr>
                                    <tr>
                                        <th>Price Trend:</th>
                                        <td>
                                            <span class="badge bg-${data.price_trend === 'up' ? 'success' : (data.price_trend === 'down' ? 'danger' : 'secondary')}">
                                                ${data.price_trend || 'N/A'}
                                            </span>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer text-muted small">
                        <div class="d-flex justify-content-between">
                            <span>${data.ai_analysis ? 'Powered by OpenAI' : 'Algorithmic analysis'}</span>
                            <span>Last updated: ${new Date().toLocaleTimeString()}</span>
                        </div>
                    </div>
                </div>
            `;
        } else {
            // Standard analysis layout (fallback)
            contentHtml = `
                <div class="card mb-3">
                    <div class="card-header d-flex justify-content-between align-items-center bg-dark text-light">
                        <h5 class="mb-0">Trading Analysis</h5>
                        <span class="badge bg-${recommendationClass}">${data.recommendation || 'N/A'}</span>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <table class="table table-sm">
                                    <tr>
                                        <th>Buying Pressure:</th>
                                        <td>
                                            <div class="progress">
                                                <div class="progress-bar bg-success" style="width: ${data.buying_pressure || 0}%">
                                                    ${data.buying_pressure || 0}%
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Selling Pressure:</th>
                                        <td>
                                            <div class="progress">
                                                <div class="progress-bar bg-danger" style="width: ${data.selling_pressure || 0}%">
                                                    ${data.selling_pressure || 0}%
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <table class="table table-sm">
                                    <tr>
                                        <th>Trades/Min:</th>
                                        <td>${data.trades_per_minute || 'N/A'}</td>
                                    </tr>
                                    <tr>
                                        <th>Price Trend:</th>
                                        <td>
                                            <span class="badge bg-${data.price_trend === 'up' ? 'success' : (data.price_trend === 'down' ? 'danger' : 'secondary')}">
                                                ${data.price_trend || 'N/A'}
                                            </span>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }
        
        analysisSection.innerHTML = contentHtml;
    }
    
    /**
     * Start automatic data updates
     */
    startAutoUpdate() {
        if (this.updateInterval) {
            this.stopAutoUpdate();
        }
        
        this.updateInterval = setInterval(() => {
            if (this.activeSymbol && !this.isUpdating) {
                this.isUpdating = true;
                this.loadSymbolData(this.activeSymbol);
                this.isUpdating = false;
            }
        }, this.updateFrequency);
        
        this.showToast(`Auto-update enabled (every ${this.updateFrequency / 1000} seconds)`);
    }
    
    /**
     * Stop automatic data updates
     */
    stopAutoUpdate() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
            this.updateInterval = null;
            this.showToast('Auto-update disabled');
        }
    }
    
    /**
     * Show a loading state in the data containers
     */
    showLoadingState() {
        const loadingHtml = `
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2 text-muted">Loading market data...</p>
            </div>
        `;
        
        if (this.marketDataContainer) {
            this.marketDataContainer.innerHTML = loadingHtml;
        }
        
        if (this.level2Container) {
            this.level2Container.innerHTML = loadingHtml;
        }
        
        if (this.timeAndSalesContainer) {
            this.timeAndSalesContainer.innerHTML = loadingHtml;
        }
    }
    
    /**
     * Clear the data display
     */
    clearDataDisplay() {
        if (this.marketDataContainer) {
            this.marketDataContainer.innerHTML = '';
        }
        
        if (this.level2Container) {
            this.level2Container.innerHTML = '';
        }
        
        if (this.timeAndSalesContainer) {
            this.timeAndSalesContainer.innerHTML = '';
        }
    }
    
    /**
     * Show an error message
     * @param {string} message - The error message to show
     */
    showError(message) {
        if (this.marketDataContainer) {
            this.marketDataContainer.innerHTML = `
                <div class="alert alert-danger">
                    <strong>Error:</strong> ${message}
                </div>
            `;
        }
        
        console.error('Market Data Error:', message);
    }
    
    /**
     * Show a toast notification
     * @param {string} message - The message to display
     */
    showToast(message) {
        // Create toast element
        const toastEl = document.createElement('div');
        toastEl.className = 'toast align-items-center text-white bg-primary border-0 position-fixed bottom-0 end-0 m-3';
        toastEl.setAttribute('role', 'alert');
        toastEl.setAttribute('aria-live', 'assertive');
        toastEl.setAttribute('aria-atomic', 'true');
        
        toastEl.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        
        // Add to document
        document.body.appendChild(toastEl);
        
        // Initialize and show
        const toast = new bootstrap.Toast(toastEl, { autohide: true, delay: 3000 });
        toast.show();
        
        // Remove from DOM after hiding
        toastEl.addEventListener('hidden.bs.toast', function() {
            toastEl.remove();
        });
    }
}

// Initialize when the document is ready
document.addEventListener('DOMContentLoaded', function() {
    window.marketDataManager = new MarketDataManager();
    
    // Load monitored symbols
    window.marketDataManager.loadMonitoredSymbols();
    
    // Enable auto-update by default
    const autoUpdateToggle = document.getElementById('auto-update-toggle');
    if (autoUpdateToggle && !autoUpdateToggle.checked) {
        autoUpdateToggle.checked = true;
        window.marketDataManager.startAutoUpdate();
    }
});