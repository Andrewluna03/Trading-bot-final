document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const captureBtn = document.getElementById('capture-btn');
    const autoCaptureToggle = document.getElementById('auto-capture-toggle');
    const aiAnalysis = document.getElementById('ai-analysis');
    const extractedText = document.getElementById('extracted-text');
    const errorMessage = document.getElementById('error-message');
    const loadingIndicator = document.getElementById('loading-indicator');
    const analysisResult = document.getElementById('analysis-result');
    const screenshotCount = document.getElementById('screenshot-count');
    const lastCaptureTime = document.getElementById('last-capture-time');
    const analysisStatus = document.getElementById('analysis-status');
    const analysisDepth = document.getElementById('analysis-depth');
    const platformType = document.getElementById('platform-type');
    const screenshotUpload = document.getElementById('screenshot-upload');
    const refreshHistoryBtn = document.getElementById('refresh-history');
    const historyContainer = document.getElementById('history-container');
    
    // Variables
    let autoCapture = false;
    let autoCaptureInterval = null;
    let captureCount = 0;
    
    // Initialize
    updateUIState('idle');
    loadAnalysisHistory();
    
    // Event listeners
    captureBtn.addEventListener('click', captureScreen);
    
    autoCaptureToggle.addEventListener('change', function() {
        autoCapture = this.checked;
        
        if (autoCapture) {
            // Start auto-capture (every 30 seconds)
            autoCaptureInterval = setInterval(captureScreen, 30000);
            showToast('Auto-capture enabled. Will capture every 30 seconds.');
        } else {
            // Stop auto-capture
            clearInterval(autoCaptureInterval);
            showToast('Auto-capture disabled.');
        }
    });
    
    // Add event listener for refresh history button
    if (refreshHistoryBtn) {
        refreshHistoryBtn.addEventListener('click', loadAnalysisHistory);
    }
    
    // Add event listener for file upload
    if (screenshotUpload) {
        screenshotUpload.addEventListener('change', function(e) {
            if (this.files && this.files[0]) {
                processUploadedFile(this.files[0]);
            }
        });
    }
    
    /**
     * Capture the screen and send to server for analysis
     */
    function captureScreen() {
        updateUIState('capturing');
        
        const formData = new FormData();
        formData.append('platform_type', platformType.value);
        formData.append('analysis_depth', analysisDepth.value);
        
        fetch('/capture', {
            method: 'POST',
            body: formData
        })
        .then(handleResponse)
        .catch(handleError);
    }
    
    /**
     * Process an uploaded screenshot file
     * @param {File} file - The uploaded file
     */
    function processUploadedFile(file) {
        updateUIState('capturing');
        
        const formData = new FormData();
        formData.append('screenshot', file);
        formData.append('platform_type', platformType.value);
        formData.append('analysis_depth', analysisDepth.value);
        
        fetch('/capture', {
            method: 'POST',
            body: formData
        })
        .then(handleResponse)
        .catch(handleError);
    }
    
    /**
     * Handle the response from the server
     * @param {Response} response - The fetch response
     */
    function handleResponse(response) {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json().then(data => {
            if (data.success) {
                // Update the UI with the results
                aiAnalysis.innerHTML = formatAnalysisText(data.analysis);
                extractedText.innerHTML = formatExtractedText(data.extracted_text);
                
                // Update stats
                captureCount++;
                screenshotCount.textContent = captureCount;
                lastCaptureTime.textContent = new Date().toLocaleTimeString();
                lastCaptureTime.className = 'badge bg-success';
                
                // Reset file upload input
                if (screenshotUpload) {
                    screenshotUpload.value = '';
                }
                
                // Refresh history
                loadAnalysisHistory();
                
                updateUIState('success');
            } else {
                throw new Error(data.error || 'Unknown error occurred');
            }
        });
    }
    
    /**
     * Handle any errors that occur during the fetch
     * @param {Error} error - The error that occurred
     */
    function handleError(error) {
        console.error('Error:', error);
        errorMessage.textContent = error.message;
        updateUIState('error');
        
        // Reset file upload input if there was an error
        if (screenshotUpload) {
            screenshotUpload.value = '';
        }
    }
    
    /**
     * Update the UI based on the current state
     * @param {string} state - The current state (idle, capturing, success, error)
     */
    function updateUIState(state) {
        // Reset all states
        loadingIndicator.classList.add('d-none');
        analysisResult.classList.add('d-none');
        errorMessage.classList.add('d-none');
        
        // Update based on current state
        switch (state) {
            case 'idle':
                analysisStatus.innerHTML = '<span class="badge bg-secondary">Idle</span>';
                captureBtn.disabled = false;
                break;
                
            case 'capturing':
                analysisStatus.innerHTML = '<span class="badge bg-warning">Analyzing...</span>';
                loadingIndicator.classList.remove('d-none');
                captureBtn.disabled = true;
                break;
                
            case 'success':
                analysisStatus.innerHTML = '<span class="badge bg-success">Analysis Complete</span>';
                analysisResult.classList.remove('d-none');
                captureBtn.disabled = false;
                break;
                
            case 'error':
                analysisStatus.innerHTML = '<span class="badge bg-danger">Error</span>';
                errorMessage.classList.remove('d-none');
                captureBtn.disabled = false;
                break;
        }
    }
    
    /**
     * Format the extracted text for display
     * @param {string} text - The extracted text
     * @returns {string} - Formatted HTML
     */
    function formatExtractedText(text) {
        if (!text || text.trim() === '') {
            return '<p class="text-muted">No text was extracted from the screen.</p>';
        }
        
        // Escape HTML and preserve whitespace
        const escapedText = text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;')
            .replace(/\n/g, '<br>');
            
        return escapedText;
    }
    
    /**
     * Format the analysis text for display
     * @param {string} text - The analysis text
     * @returns {string} - Formatted HTML
     */
    function formatAnalysisText(text) {
        if (!text || text.trim() === '') {
            return '<p class="text-muted">No analysis available.</p>';
        }
        
        // Process markdown-style formatting (basic)
        let formatted = text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')  // Bold
            .replace(/\*(.*?)\*/g, '<em>$1</em>')              // Italic
            .replace(/\n\n/g, '</p><p>')                       // Paragraphs
            .replace(/\n/g, '<br>');                           // Line breaks
        
        // Format trading recommendations
        formatted = formatted
            .replace(/\b(Recommendation|Trading Signal|Signal|Action):\s*(Enter|Buy|Long)\b/gi, 
                    '$1: <span class="recommendation-enter">$2</span>')
            .replace(/\b(Recommendation|Trading Signal|Signal|Action):\s*(Exit|Sell|Short)\b/gi, 
                    '$1: <span class="recommendation-exit">$2</span>')
            .replace(/\b(Recommendation|Trading Signal|Signal|Action):\s*(Hold)\b/gi, 
                    '$1: <span class="recommendation-hold">$2</span>')
            .replace(/\b(Recommendation|Trading Signal|Signal|Action):\s*(Wait)\b/gi, 
                    '$1: <span class="recommendation-wait">$2</span>');
        
        // Highlight bid and ask references
        formatted = formatted
            .replace(/\b(Bid|Bids):/gi, '<strong>Bid:</strong>')
            .replace(/\b(Ask|Asks|Offer|Offers):/gi, '<strong>Ask:</strong>')
            .replace(/\b(Spread):/gi, '<strong>Spread:</strong>')
            .replace(/\b(Speed|Volume|Pressure):/gi, '<strong>$1:</strong>');
            
        // Add paragraph tags if not present
        if (!formatted.startsWith('<p>')) {
            formatted = '<p>' + formatted;
        }
        if (!formatted.endsWith('</p>')) {
            formatted += '</p>';
        }
        
        return formatted;
    }
    
    /**
     * Load analysis history from the server
     */
    function loadAnalysisHistory() {
        if (!historyContainer) return;
        
        // Show loading state
        historyContainer.innerHTML = `
            <div class="text-center py-3">
                <div class="spinner-border spinner-border-sm text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="text-muted mb-0 mt-2">Loading history...</p>
            </div>
        `;
        
        // Fetch history data
        fetch('/analysis-history')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to load history');
                }
                return response.json();
            })
            .then(data => {
                if (data.success && data.history && data.history.length > 0) {
                    // Generate history items
                    let historyHtml = '';
                    
                    data.history.forEach(item => {
                        const timestamp = new Date(item.timestamp).toLocaleString();
                        const symbol = item.symbol || 'Unknown';
                        let recommendationClass = 'secondary';
                        
                        if (item.recommendation) {
                            switch(item.recommendation.toLowerCase()) {
                                case 'enter':
                                    recommendationClass = 'success';
                                    break;
                                case 'exit':
                                    recommendationClass = 'danger';
                                    break;
                                case 'hold':
                                    recommendationClass = 'warning';
                                    break;
                                case 'wait':
                                    recommendationClass = 'info';
                                    break;
                            }
                        }
                        
                        historyHtml += `
                            <div class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between align-items-center">
                                    <h6 class="mb-1">${symbol}</h6>
                                    <small class="text-muted">${timestamp}</small>
                                </div>
                                <div class="d-flex justify-content-between align-items-center mt-2">
                                    ${item.bid_price ? `<small>Bid: $${item.bid_price.toFixed(2)}</small>` : ''}
                                    ${item.ask_price ? `<small>Ask: $${item.ask_price.toFixed(2)}</small>` : ''}
                                    ${item.spread ? `<small>Spread: $${item.spread.toFixed(2)}</small>` : ''}
                                    ${item.recommendation ? 
                                        `<span class="badge bg-${recommendationClass}">${item.recommendation}</span>` : ''}
                                </div>
                            </div>
                        `;
                    });
                    
                    historyContainer.innerHTML = historyHtml;
                } else {
                    // Show empty state
                    historyContainer.innerHTML = `
                        <div class="text-center py-3">
                            <p class="text-muted mb-0">No analysis history available</p>
                        </div>
                    `;
                }
            })
            .catch(error => {
                console.error('Error loading history:', error);
                historyContainer.innerHTML = `
                    <div class="text-center py-3">
                        <p class="text-danger mb-0">Failed to load history</p>
                    </div>
                `;
            });
    }

    /**
     * Show a toast notification
     * @param {string} message - The message to display
     */
    function showToast(message) {
        // Create toast element
        const toastEl = document.createElement('div');
        toastEl.className = 'toast align-items-center text-white bg-primary border-0 position-fixed bottom-0 end-0 m-3';
        toastEl.setAttribute('role', 'alert');
        toastEl.setAttribute('aria-live', 'assertive');
        toastEl.setAttribute('aria-atomic', 'true');
        
        toastEl.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        
        // Add to document
        document.body.appendChild(toastEl);
        
        // Initialize and show
        const toast = new bootstrap.Toast(toastEl, { autohide: true, delay: 3000 });
        toast.show();
        
        // Remove from DOM after hiding
        toastEl.addEventListener('hidden.bs.toast', function() {
            toastEl.remove();
        });
    }
});
