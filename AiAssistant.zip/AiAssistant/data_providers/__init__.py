"""
Data provider module for market data feeds
Conditional imports based on configuration
"""
import os

# Use REALTIME_ENABLED flag to determine which data source to use
REALTIME_ENABLED = True  # Force live data when possible

# Import the appropriate data feed implementation
if REALTIME_ENABLED:
    from .real_data import DatabentoFeed as MarketDataFeed
else:
    from .simulated_data import SimulatedFeed as MarketDataFeed

# Export the MarketDataFeed as the unified interface
__all__ = ['MarketDataFeed', 'REALTIME_ENABLED']