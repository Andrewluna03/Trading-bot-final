"""
Simulated market data feed implementation
This module provides simulated market data when real data is unavailable
"""
import asyncio
import logging
import os
import json
from typing import Dict, Any, List, Callable, Optional, Union

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SimulatedFeed:
    """
    Simulated market data feed used when real-time data is unavailable
    """
    def __init__(self):
        """Initialize the simulated market data feed"""
        # Import the actual implementation here to avoid circular imports
        from databento_websocket import DatabentoWebSocket
        
        self.client = DatabentoWebSocket()
        self.subscriptions = {}
        self.connected = False
        
        logger.info("Initialized simulated market data feed")

    async def connect(self) -> bool:
        """
        Connect to the simulated market data feed
        
        Returns:
            bool: Success status
        """
        # Explicitly enable simulation mode
        self.client.enable_simulated_mode(True)
        
        # Connect to start the simulation
        success = await self.client.connect()
        self.connected = success
        
        if success:
            logger.info("Successfully started simulated market data feed")
        else:
            logger.error("Failed to start simulated market data feed")
            
        return success
        
    async def disconnect(self) -> bool:
        """
        Disconnect from the simulated market data feed
        
        Returns:
            bool: Success status
        """
        success = await self.client.disconnect()
        self.connected = False
        return success
        
    def is_connected(self) -> bool:
        """
        Check if the simulated feed is active
        
        Returns:
            bool: Connection status
        """
        return self.client.is_connected()
        
    def is_using_real_data(self) -> bool:
        """
        Check if using real market data (vs simulated)
        
        Returns:
            bool: Always False for simulated feed
        """
        return False
        
    def subscribe_level2(self, symbol: str, callback: Any = None) -> bool:
        """
        Subscribe to simulated Level 2 market depth data
        
        Args:
            symbol (str): The stock symbol to subscribe to
            callback (callable): Function to call with simulated updates
            
        Returns:
            bool: Success status
        """
        return self.client.subscribe_level2(symbol, callback)
        
    def subscribe_trades(self, symbol: str, callback: Any = None) -> bool:
        """
        Subscribe to simulated time & sales data
        
        Args:
            symbol (str): The stock symbol to subscribe to
            callback (callable): Function to call with simulated updates
            
        Returns:
            bool: Success status
        """
        return self.client.subscribe_trades(symbol, callback)
        
    def subscribe_quotes(self, symbol: str, callback: Any = None) -> bool:
        """
        Subscribe to simulated quote data
        
        Args:
            symbol (str): The stock symbol to subscribe to
            callback (callable): Function to call with simulated updates
            
        Returns:
            bool: Success status
        """
        return self.client.subscribe_quotes(symbol, callback)
        
    def unsubscribe(self, symbol: str, data_type: str = None) -> bool:
        """
        Unsubscribe from a simulated data feed
        
        Args:
            symbol (str): The stock symbol to unsubscribe from
            data_type (str, optional): Type of data feed ("level2", "trades", "quotes")
                                      If None, unsubscribe from all types
                                      
        Returns:
            bool: Success status
        """
        # Map our data type names to Databento schema names
        schema_map = {
            "level2": "mbp_10",
            "trades": "trades",
            "quotes": "bbo_1s"
        }
        
        schema = schema_map.get(data_type) if data_type else None
        return self.client.unsubscribe(symbol, schema)
        
    def get_active_subscriptions(self) -> List[Dict[str, Any]]:
        """
        Get a list of active subscriptions
        
        Returns:
            List[Dict]: Active subscriptions
        """
        return self.client.get_active_subscriptions()