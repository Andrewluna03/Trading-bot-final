"""
Real market data feed implementation using the Databento API
This module implements real-time market data connections
"""
import asyncio
import logging
import os
import json
from typing import Dict, Any, List, Callable, Optional, Union

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabentoFeed:
    """
    Real-time market data feed using Databento API
    """
    def __init__(self):
        """Initialize the real-time market data feed"""
        # Import the actual implementation here to avoid circular imports
        from databento_websocket import DatabentoWebSocket
        
        self.client = DatabentoWebSocket()
        self.subscriptions = {}
        self.connected = False
        self.api_key = os.environ.get("DATABENTO_API_KEY")
        
        if not self.api_key:
            logger.critical("DATABENTO_API_KEY environment variable is not set. Live data will not be available.")
            raise ValueError("DATABENTO_API_KEY environment variable must be set for real data feed")
        
        logger.info("Initialized real-time market data feed with Databento")

    async def connect(self) -> bool:
        """
        Connect to the real-time market data feed
        
        Returns:
            bool: Success status
        """
        # Ensure simulation mode is disabled
        self.client.enable_simulated_mode(False)
        
        # Connect to the real API
        success = await self.client.connect()
        self.connected = success
        
        if success:
            logger.info("Successfully connected to Databento real-time API")
            # Print a clear visual indicator that we're using real datacenter feed
            print("\n✅ USING REAL DATACENTER FEED: Databento LIVE\n")
        else:
            logger.error("Failed to connect to Databento real-time API")
            
        return success
        
    async def disconnect(self) -> bool:
        """
        Disconnect from the real-time market data feed
        
        Returns:
            bool: Success status
        """
        success = await self.client.disconnect()
        self.connected = False
        return success
        
    def is_connected(self) -> bool:
        """
        Check if connected to the market data feed
        
        Returns:
            bool: Connection status
        """
        return self.client.is_connected() and not self.client.simulated_mode
        
    def is_using_real_data(self) -> bool:
        """
        Check if using real market data (vs simulated)
        
        Returns:
            bool: True if using real data, False if using simulation
        """
        return self.is_connected() and not self.client.simulated_mode
        
    def subscribe_level2(self, symbol: str, callback: Any = None) -> bool:
        """
        Subscribe to Level 2 market depth data
        
        Args:
            symbol (str): The stock symbol to subscribe to
            callback (callable): Function to call with updates
            
        Returns:
            bool: Success status
        """
        return self.client.subscribe_level2(symbol, callback)
        
    def subscribe_trades(self, symbol: str, callback: Any = None) -> bool:
        """
        Subscribe to time & sales data
        
        Args:
            symbol (str): The stock symbol to subscribe to
            callback (callable): Function to call with updates
            
        Returns:
            bool: Success status
        """
        return self.client.subscribe_trades(symbol, callback)
        
    def subscribe_quotes(self, symbol: str, callback: Any = None) -> bool:
        """
        Subscribe to quote data
        
        Args:
            symbol (str): The stock symbol to subscribe to
            callback (callable): Function to call with updates
            
        Returns:
            bool: Success status
        """
        return self.client.subscribe_quotes(symbol, callback)
        
    def unsubscribe(self, symbol: str, data_type: Optional[str] = None) -> bool:
        """
        Unsubscribe from a data feed
        
        Args:
            symbol (str): The stock symbol to unsubscribe from
            data_type (str, optional): Type of data feed ("level2", "trades", "quotes")
                                      If None, unsubscribe from all types
                                      
        Returns:
            bool: Success status
        """
        # Map our data type names to Databento schema names
        schema_map = {
            "level2": "mbp_10",
            "trades": "trades",
            "quotes": "bbo_1s"
        }
        
        schema = schema_map.get(data_type) if data_type else None
        return self.client.unsubscribe(symbol, schema)
        
    def get_active_subscriptions(self) -> List[Dict[str, Any]]:
        """
        Get a list of active subscriptions
        
        Returns:
            List[Dict]: Active subscriptions
        """
        return self.client.get_active_subscriptions()