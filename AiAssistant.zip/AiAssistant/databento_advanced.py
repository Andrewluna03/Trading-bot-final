"""
Advanced Databento integration for professional market data
Uses Databento's Python API for high-performance data access
"""

import os
import logging
import json
import pandas as pd
from datetime import datetime, timedelta, timezone
from typing import Dict, Any, List, Optional, Tuple, Union

from databento import Historical, Dataset, Schema

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabentoAdvanced:
    """Advanced Databento client for professional market data access"""
    
    def __init__(self):
        """Initialize the Databento advanced client"""
        self.api_key = os.environ.get("DATABENTO_API_KEY")
        self.historical = None
        self.datasets = {}
        
        if self.api_key:
            try:
                self.historical = Historical(self.api_key)
                logger.info("Advanced Databento client initialized")
                
                # Get available datasets
                self.refresh_datasets()
            except Exception as e:
                logger.error(f"Error initializing Databento client: {str(e)}")
                self.historical = None
        else:
            logger.warning("DATABENTO_API_KEY not found. Advanced Databento functionality unavailable.")
    
    def refresh_datasets(self):
        """Refresh the available datasets information"""
        if not self.historical:
            return
        
        try:
            # Hard-code the common datasets since the API doesn't support listing
            self.datasets = {
                'XNAS.ITCH': {
                    'stype_in': 'raw_symbol',
                    'start': '2023-01-01',
                    'end': '2025-04-10',
                    'description': 'NASDAQ TotalView-ITCH'
                },
                'XNYS.PILLAR': {
                    'stype_in': 'raw_symbol',
                    'start': '2023-01-01',
                    'end': '2025-04-10',
                    'description': 'NYSE Integrated'
                },
                'GLBX.MDP3': {
                    'stype_in': 'raw_symbol',
                    'start': '2023-01-01',
                    'end': '2025-04-10',
                    'description': 'CME Globex'
                },
                'DBEQ.BASIC': {
                    'stype_in': 'ticker',
                    'start': '2023-01-01',
                    'end': '2025-04-10',
                    'description': 'Databento Equities Basic'
                }
            }
            logger.info(f"Loaded {len(self.datasets)} available datasets")
        except Exception as e:
            logger.error(f"Error setting up datasets: {str(e)}")
    
    def list_available_datasets(self) -> Dict[str, Any]:
        """
        List all available Databento datasets
        
        Returns:
            Dict: Available datasets and their details
        """
        return {
            "success": True,
            "available": bool(self.historical),
            "datasets": self.datasets
        }
    
    def list_symbols(self, dataset: str, stype: str = None, limit: int = 100) -> Dict[str, Any]:
        """
        List available symbols for a dataset
        
        Args:
            dataset (str): Dataset name (e.g., 'XNAS.ITCH')
            stype (str): Symbol type filter
            limit (int): Maximum symbols to return
            
        Returns:
            Dict: Available symbols
        """
        if not self.historical:
            return self._error_response("Databento client not initialized", "authentication_error")
            
        try:
            # Convert dataset string to Dataset enum if needed
            if isinstance(dataset, str):
                try:
                    dataset_enum = Dataset[dataset.replace('.', '_')]
                except (KeyError, ValueError):
                    return self._error_response(f"Invalid dataset: {dataset}", "invalid_dataset")
            else:
                dataset_enum = dataset
            
            # Since getting the actual symbol list is challenging with the current API,
            # we'll provide a set of common symbols for each dataset
            common_symbols = {
                'XNAS_ITCH': [
                    {'symbol': 'AAPL', 'description': 'Apple Inc.'},
                    {'symbol': 'MSFT', 'description': 'Microsoft Corporation'},
                    {'symbol': 'AMZN', 'description': 'Amazon.com, Inc.'},
                    {'symbol': 'GOOGL', 'description': 'Alphabet Inc.'},
                    {'symbol': 'META', 'description': 'Meta Platforms, Inc.'},
                    {'symbol': 'TSLA', 'description': 'Tesla, Inc.'},
                    {'symbol': 'NVDA', 'description': 'NVIDIA Corporation'},
                    {'symbol': 'AMD', 'description': 'Advanced Micro Devices, Inc.'},
                    {'symbol': 'INTC', 'description': 'Intel Corporation'},
                    {'symbol': 'CSCO', 'description': 'Cisco Systems, Inc.'}
                ],
                'XNYS_PILLAR': [
                    {'symbol': 'JPM', 'description': 'JPMorgan Chase & Co.'},
                    {'symbol': 'BAC', 'description': 'Bank of America Corporation'},
                    {'symbol': 'WMT', 'description': 'Walmart Inc.'},
                    {'symbol': 'DIS', 'description': 'The Walt Disney Company'},
                    {'symbol': 'XOM', 'description': 'Exxon Mobil Corporation'},
                    {'symbol': 'CVX', 'description': 'Chevron Corporation'},
                    {'symbol': 'JNJ', 'description': 'Johnson & Johnson'},
                    {'symbol': 'PG', 'description': 'The Procter & Gamble Company'},
                    {'symbol': 'KO', 'description': 'The Coca-Cola Company'},
                    {'symbol': 'PFE', 'description': 'Pfizer Inc.'}
                ],
                'GLBX_MDP3': [
                    {'symbol': 'ES', 'description': 'E-mini S&P 500 Futures'},
                    {'symbol': 'NQ', 'description': 'E-mini NASDAQ-100 Futures'},
                    {'symbol': 'YM', 'description': 'E-mini Dow Futures'},
                    {'symbol': 'CL', 'description': 'Crude Oil Futures'},
                    {'symbol': 'GC', 'description': 'Gold Futures'},
                    {'symbol': 'SI', 'description': 'Silver Futures'},
                    {'symbol': 'ZB', 'description': 'U.S. Treasury Bond Futures'},
                    {'symbol': 'ZN', 'description': '10-Year US Treasury Note Futures'},
                    {'symbol': 'ZF', 'description': '5-Year US Treasury Note Futures'},
                    {'symbol': 'ZT', 'description': '2-Year US Treasury Note Futures'}
                ],
                'DBEQ_BASIC': [
                    {'symbol': 'AAPL', 'description': 'Apple Inc.'},
                    {'symbol': 'MSFT', 'description': 'Microsoft Corporation'},
                    {'symbol': 'AMZN', 'description': 'Amazon.com, Inc.'},
                    {'symbol': 'GOOGL', 'description': 'Alphabet Inc.'},
                    {'symbol': 'META', 'description': 'Meta Platforms, Inc.'},
                    {'symbol': 'TSLA', 'description': 'Tesla, Inc.'},
                    {'symbol': 'NVDA', 'description': 'NVIDIA Corporation'},
                    {'symbol': 'JPM', 'description': 'JPMorgan Chase & Co.'},
                    {'symbol': 'JNJ', 'description': 'Johnson & Johnson'},
                    {'symbol': 'V', 'description': 'Visa Inc.'}
                ]
            }
            
            # Get symbols for the selected dataset
            # We need to handle two formats: 'XNAS_ITCH' and 'XNAS.ITCH'
            dataset_str = str(dataset_enum)
            # Try with underscore format first
            symbols = common_symbols.get(dataset_str, [])
            # If empty, try with dot format (replace underscore with dot)
            if not symbols and '_' in dataset_str:
                dot_format = dataset_str.replace('_', '.')
                symbols = common_symbols.get(dot_format, [])
            # If still empty, try with underscore format from dot format
            if not symbols and '.' in dataset_str:
                underscore_format = dataset_str.replace('.', '_')
                symbols = common_symbols.get(underscore_format, [])
            
            # Apply symbol type filter if provided
            if stype:
                # In a real implementation, this would filter by symbol type
                # For this mock, we'll just return the same symbols
                pass
            
            # Apply limit
            symbols = symbols[:limit]
            
            return {
                "success": True,
                "dataset": dataset_str,
                "symbol_count": len(symbols),
                "symbols": symbols
            }
            
        except Exception as e:
            logger.error(f"Error listing symbols: {str(e)}")
            return self._error_response(f"Failed to list symbols: {str(e)}", "api_error")
    
    def get_market_depth(self, symbol: str, dataset: str = "XNAS_ITCH", 
                        date: str = None, depth: int = 10) -> Dict[str, Any]:
        """
        Get market depth data (order book) for a symbol
        
        Args:
            symbol (str): Symbol to retrieve data for
            dataset (str): Dataset name
            date (str): Date in ISO format (YYYY-MM-DD)
            depth (int): Depth levels to include
            
        Returns:
            Dict: Market depth data
        """
        if not self.historical:
            return self._error_response("Databento client not initialized", "authentication_error")
        
        try:
            # Convert dataset string to Dataset enum
            try:
                dataset_enum = Dataset[dataset]
            except (KeyError, ValueError):
                return self._error_response(f"Invalid dataset: {dataset}", "invalid_dataset")
            
            # Use current date if not specified
            if not date:
                # Find the latest available date for this dataset
                dataset_info = self.datasets.get(dataset.replace('_', '.'))
                if dataset_info:
                    date = dataset_info['end'].split('T')[0]  # Extract date part
                else:
                    # Default to yesterday
                    date = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
            
            # Request market by order data
            data = self.historical.timeseries.get_range(
                dataset=dataset_enum,
                symbols=[symbol],
                schema=Schema.MBO,  # Market by Order
                start=f"{date}T00:00:00",
                end=f"{date}T23:59:59",
                limit=5000,  # Get enough data to build a complete book
            )
            
            # Process data into order book
            if hasattr(data, 'to_df'):
                df = data.to_df()
                
                if df.empty:
                    return {
                        "success": True,
                        "symbol": symbol,
                        "timestamp": datetime.now().isoformat(),
                        "bids": [],
                        "asks": [],
                        "warning": "No data available for the requested date"
                    }
                
                # Get the latest timestamp from the data
                latest_time = df['ts_event'].max()
                
                # Handle different timestamp types
                if isinstance(latest_time, pd.Timestamp):
                    # If it's already a pandas Timestamp, use it directly
                    recent_df = df[df['ts_event'] > latest_time - pd.Timedelta(seconds=5)]
                else:
                    # If it's a nanosecond timestamp as integer
                    recent_df = df[df['ts_event'] > latest_time - 5_000_000_000]  # 5 seconds in nanoseconds
                
                # Extract active orders
                active_orders = {}
                
                # Process order events to build the book
                for _, row in recent_df.iterrows():
                    order_id = row.get('order_id')
                    action = row.get('action')
                    
                    if action == 'A':  # Add order
                        active_orders[order_id] = {
                            'price': row.get('price'),
                            'size': row.get('size'),
                            'side': 'bid' if row.get('side') == 'B' else 'ask'
                        }
                    elif action == 'D':  # Delete order
                        if order_id in active_orders:
                            del active_orders[order_id]
                    elif action == 'R':  # Replace order
                        if order_id in active_orders:
                            active_orders[order_id]['price'] = row.get('price')
                            active_orders[order_id]['size'] = row.get('size')
                    elif action == 'E':  # Execute order
                        if order_id in active_orders:
                            # Reduce size
                            active_orders[order_id]['size'] -= row.get('size')
                            # Remove if size is 0
                            if active_orders[order_id]['size'] <= 0:
                                del active_orders[order_id]
                
                # Separate bids and asks
                bids = []
                asks = []
                
                for order_id, order in active_orders.items():
                    if order['side'] == 'bid':
                        bids.append({
                            'price': float(order['price']),
                            'size': int(order['size'])
                        })
                    else:
                        asks.append({
                            'price': float(order['price']),
                            'size': int(order['size'])
                        })
                
                # Aggregate by price level
                bid_levels = {}
                ask_levels = {}
                
                for bid in bids:
                    price = bid['price']
                    if price in bid_levels:
                        bid_levels[price] += bid['size']
                    else:
                        bid_levels[price] = bid['size']
                
                for ask in asks:
                    price = ask['price']
                    if price in ask_levels:
                        ask_levels[price] += ask['size']
                    else:
                        ask_levels[price] = ask['size']
                
                # Convert to lists and sort
                bid_list = [{'price': price, 'size': size} for price, size in bid_levels.items()]
                ask_list = [{'price': price, 'size': size} for price, size in ask_levels.items()]
                
                bid_list.sort(key=lambda x: x['price'], reverse=True)  # Highest bids first
                ask_list.sort(key=lambda x: x['price'])  # Lowest asks first
                
                # Limit depth
                bid_list = bid_list[:depth]
                ask_list = ask_list[:depth]
                
                # Format timestamp based on type
                if isinstance(latest_time, pd.Timestamp):
                    formatted_time = latest_time.isoformat()
                else:
                    # Assume it's a nanosecond timestamp as integer
                    formatted_time = datetime.fromtimestamp(latest_time / 1e9).isoformat()
                
                return {
                    "success": True,
                    "symbol": symbol,
                    "timestamp": formatted_time,
                    "bids": bid_list,
                    "asks": ask_list,
                    "source": "databento_historical"
                }
            else:
                return self._error_response("Failed to process market depth data", "processing_error")
                
        except Exception as e:
            logger.error(f"Error getting market depth: {str(e)}")
            return self._error_response(f"Failed to get market depth: {str(e)}", "api_error")
    
    def get_trades(self, symbol: str, dataset: str = "XNAS_ITCH", 
                 date: str = None, limit: int = 50) -> Dict[str, Any]:
        """
        Get trades (time & sales) data for a symbol
        
        Args:
            symbol (str): Symbol to retrieve data for
            dataset (str): Dataset name
            date (str): Date in ISO format (YYYY-MM-DD)
            limit (int): Maximum trades to return
            
        Returns:
            Dict: Trades data
        """
        if not self.historical:
            return self._error_response("Databento client not initialized", "authentication_error")
        
        try:
            # Convert dataset string to Dataset enum
            try:
                dataset_enum = Dataset[dataset]
            except (KeyError, ValueError):
                return self._error_response(f"Invalid dataset: {dataset}", "invalid_dataset")
            
            # Use current date if not specified
            if not date:
                # Find the latest available date for this dataset
                dataset_info = self.datasets.get(dataset.replace('_', '.'))
                if dataset_info:
                    date = dataset_info['end'].split('T')[0]  # Extract date part
                else:
                    # Default to yesterday
                    date = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
            
            # Request trades data
            data = self.historical.timeseries.get_range(
                dataset=dataset_enum,
                symbols=[symbol],
                schema=Schema.TRADES,
                start=f"{date}T00:00:00",
                end=f"{date}T23:59:59",
                limit=limit
            )
            
            # Process trades data
            if hasattr(data, 'to_df'):
                df = data.to_df()
                
                if df.empty:
                    return {
                        "success": True,
                        "symbol": symbol,
                        "trades": [],
                        "warning": "No trades data available for the requested date"
                    }
                
                # Sort by timestamp descending (newest first)
                df = df.sort_values('ts_event', ascending=False)
                
                # Convert to list of trades
                trades = []
                for _, row in df.head(limit).iterrows():
                    # Handle timestamp conversion based on type
                    ts = row['ts_event']
                    if isinstance(ts, pd.Timestamp):
                        trade_time = ts.isoformat()
                    else:
                        # Assume it's a nanosecond timestamp as integer
                        trade_time = datetime.fromtimestamp(ts / 1e9).isoformat()  # Convert from nanoseconds
                    
                    # Map exchange codes to names
                    exchange_map = {
                        'Q': 'NASDAQ',
                        'N': 'NYSE',
                        'A': 'AMEX',
                        'P': 'ARCA',
                        'Z': 'BATS',
                        'T': 'NASDAQ_TRF',
                        'B': 'NASDAQ_BX',
                        'D': 'FINRA_ADF'
                    }
                    
                    exchange_code = row.get('exchange', 'Q')
                    exchange = exchange_map.get(exchange_code, exchange_code)
                    
                    # Determine trade side (buyer/seller initiated)
                    is_buyer_maker = False
                    if 'side' in row:
                        is_buyer_maker = row['side'] == 'B'
                    
                    trade = {
                        "timestamp": trade_time,
                        "price": float(row['price']),
                        "size": int(row['size']),
                        "exchange": exchange,
                        "trade_id": f"{symbol}-{hash(str(row['ts_event']))}",
                        "is_buyer_maker": is_buyer_maker
                    }
                    trades.append(trade)
                
                return {
                    "success": True,
                    "symbol": symbol,
                    "trades": trades,
                    "count": len(trades),
                    "source": "databento_historical"
                }
            else:
                return self._error_response("Failed to process trades data", "processing_error")
                
        except Exception as e:
            logger.error(f"Error getting trades: {str(e)}")
            return self._error_response(f"Failed to get trades: {str(e)}", "api_error")
    
    def get_quotes(self, symbol: str, dataset: str = "XNAS_ITCH", 
                  date: str = None, limit: int = 50) -> Dict[str, Any]:
        """
        Get quotes (NBBO - National Best Bid and Offer) data for a symbol
        
        Args:
            symbol (str): Symbol to retrieve data for
            dataset (str): Dataset name
            date (str): Date in ISO format (YYYY-MM-DD)
            limit (int): Maximum quotes to return
            
        Returns:
            Dict: Quotes data
        """
        if not self.historical:
            return self._error_response("Databento client not initialized", "authentication_error")
        
        try:
            # Convert dataset string to Dataset enum
            try:
                dataset_enum = Dataset[dataset]
            except (KeyError, ValueError):
                return self._error_response(f"Invalid dataset: {dataset}", "invalid_dataset")
            
            # Use current date if not specified
            if not date:
                # Find the latest available date for this dataset
                dataset_info = self.datasets.get(dataset.replace('_', '.'))
                if dataset_info:
                    date = dataset_info['end'].split('T')[0]  # Extract date part
                else:
                    # Default to yesterday
                    date = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
            
            # Request quotes data (using BBO_1S for quotes)
            data = self.historical.timeseries.get_range(
                dataset=dataset_enum,
                symbols=[symbol],
                schema=Schema.BBO_1S,  # Best Bid and Offer 1-second snapshots
                start=f"{date}T00:00:00",
                end=f"{date}T23:59:59",
                limit=limit
            )
            
            # Process quotes data
            if hasattr(data, 'to_df'):
                df = data.to_df()
                
                if df.empty:
                    return {
                        "success": True,
                        "symbol": symbol,
                        "quotes": [],
                        "warning": "No quotes data available for the requested date"
                    }
                
                # Sort by timestamp descending (newest first)
                df = df.sort_values('ts_event', ascending=False)
                
                # Get the latest quote for market data
                latest = df.iloc[0]
                
                # Print column names to debug
                logger.debug(f"BBO_1S DataFrame columns: {df.columns.tolist()}")
                
                # Handle timestamp conversion based on type
                ts = latest['ts_event']
                if isinstance(ts, pd.Timestamp):
                    latest_time = ts.isoformat()
                else:
                    # Assume it's a nanosecond timestamp as integer
                    latest_time = datetime.fromtimestamp(ts / 1e9).isoformat()  # Convert from nanoseconds
                
                # Based on the debug log, we know the actual column names
                # bid_px_00, ask_px_00, bid_sz_00, ask_sz_00 are available directly
                
                # Get values with appropriate defaults
                bid_price = float(latest.get('bid_px_00', 0))
                bid_size = int(latest.get('bid_sz_00', 0))
                ask_price = float(latest.get('ask_px_00', 0))
                ask_size = int(latest.get('ask_sz_00', 0))
                
                market_data = {
                    "bid_price": bid_price,
                    "bid_size": bid_size,
                    "ask_price": ask_price,
                    "ask_size": ask_size,
                    "spread": round(ask_price - bid_price, 4) if ask_price > 0 and bid_price > 0 else 0,
                    "last_update": latest_time
                }
                
                # Convert to list of quotes
                quotes = []
                for _, row in df.head(limit).iterrows():
                    # Handle timestamp conversion based on type
                    ts = row['ts_event']
                    if isinstance(ts, pd.Timestamp):
                        quote_time = ts.isoformat()
                    else:
                        # Assume it's a nanosecond timestamp as integer
                        quote_time = datetime.fromtimestamp(ts / 1e9).isoformat()  # Convert from nanoseconds
                    
                    # Use the correct column names based on BBO_1S schema
                    bid_price = float(row.get('bid_px_00', 0))
                    bid_size = int(row.get('bid_sz_00', 0))
                    ask_price = float(row.get('ask_px_00', 0))
                    ask_size = int(row.get('ask_sz_00', 0))
                    
                    quote = {
                        "timestamp": quote_time,
                        "bid_price": bid_price,
                        "bid_size": bid_size,
                        "ask_price": ask_price,
                        "ask_size": ask_size,
                        "spread": round(ask_price - bid_price, 4) if ask_price > 0 and bid_price > 0 else 0
                    }
                    quotes.append(quote)
                
                return {
                    "success": True,
                    "symbol": symbol,
                    "market_data": market_data,
                    "quotes": quotes,
                    "count": len(quotes),
                    "source": "databento_historical"
                }
            else:
                return self._error_response("Failed to process quotes data", "processing_error")
                
        except Exception as e:
            logger.error(f"Error getting quotes: {str(e)}")
            return self._error_response(f"Failed to get quotes: {str(e)}", "api_error")
    
    def get_bars(self, symbol: str, dataset: str = "XNAS_ITCH", 
                interval: str = 'minute', date: str = None, limit: int = 50) -> Dict[str, Any]:
        """
        Get bar (OHLCV) data for a symbol
        
        Args:
            symbol (str): Symbol to retrieve data for
            dataset (str): Dataset name
            interval (str): Bar interval ('minute', 'hour', 'day')
            date (str): Date in ISO format (YYYY-MM-DD)
            limit (int): Maximum bars to return
            
        Returns:
            Dict: Bar data
        """
        if not self.historical:
            return self._error_response("Databento client not initialized", "authentication_error")
        
        try:
            # Convert dataset string to Dataset enum
            try:
                dataset_enum = Dataset[dataset]
            except (KeyError, ValueError):
                return self._error_response(f"Invalid dataset: {dataset}", "invalid_dataset")
            
            # Use current date if not specified
            if not date:
                # Find the latest available date for this dataset
                dataset_info = self.datasets.get(dataset.replace('_', '.'))
                if dataset_info:
                    date = dataset_info['end'].split('T')[0]  # Extract date part
                else:
                    # Default to yesterday
                    date = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
            
            # Request trades data to build bars
            data = self.historical.timeseries.get_range(
                dataset=dataset_enum,
                symbols=[symbol],
                schema=Schema.TRADES,
                start=f"{date}T00:00:00",
                end=f"{date}T23:59:59",
                limit=10000  # Get enough data to build bars
            )
            
            # Process trades data into bars
            if hasattr(data, 'to_df'):
                df = data.to_df()
                
                if df.empty:
                    return {
                        "success": True,
                        "symbol": symbol,
                        "bars": [],
                        "warning": "No data available for the requested date"
                    }
                
                # Convert timestamp to datetime
                df['datetime'] = pd.to_datetime(df['ts_event'], unit='ns')
                
                # Set the interval for resampling
                resample_map = {
                    'minute': '1T',
                    'hour': '1H',
                    'day': '1D'
                }
                
                resample_interval = resample_map.get(interval, '1T')
                
                # Resample to create OHLCV bars
                ohlc = df.set_index('datetime').resample(resample_interval).agg({
                    'price': ['first', 'max', 'min', 'last'],
                    'size': 'sum'
                })
                
                # Flatten the column multi-index
                ohlc.columns = ['open', 'high', 'low', 'close', 'volume']
                
                # Reset index to get datetime as a column
                ohlc = ohlc.reset_index()
                
                # Convert to list of bars
                bars = []
                for _, row in ohlc.tail(limit).iterrows():
                    bar_time = row['datetime'].isoformat()
                    
                    bar = {
                        "timestamp": bar_time,
                        "open": float(row['open']),
                        "high": float(row['high']),
                        "low": float(row['low']),
                        "close": float(row['close']),
                        "volume": int(row['volume'])
                    }
                    bars.append(bar)
                
                # Sort bars with newest first to match other APIs
                bars.reverse()
                
                return {
                    "success": True,
                    "symbol": symbol,
                    "interval": interval,
                    "bars": bars,
                    "count": len(bars),
                    "source": "databento_historical"
                }
            else:
                return self._error_response("Failed to process bar data", "processing_error")
                
        except Exception as e:
            logger.error(f"Error getting bars: {str(e)}")
            return self._error_response(f"Failed to get bars: {str(e)}", "api_error")
    
    def download_historical_data(self, symbol: str, dataset: str = "XNAS_ITCH", 
                               schema: str = "TRADES", date_range: Tuple[str, str] = None,
                               output_path: str = "./data") -> Dict[str, Any]:
        """
        Download historical data for a symbol to a local file
        
        Args:
            symbol (str): Symbol to download data for
            dataset (str): Dataset name
            schema (str): Schema type (TRADES, QUOTE, MBO, etc.)
            date_range (Tuple[str, str]): Start and end dates in ISO format (YYYY-MM-DD)
            output_path (str): Path to save the data file
            
        Returns:
            Dict: Download status
        """
        if not self.historical:
            return self._error_response("Databento client not initialized", "authentication_error")
        
        try:
            # Convert dataset string to Dataset enum
            try:
                dataset_enum = Dataset[dataset]
            except (KeyError, ValueError):
                return self._error_response(f"Invalid dataset: {dataset}", "invalid_dataset")
            
            # Convert schema string to Schema enum
            try:
                schema_enum = Schema[schema]
            except (KeyError, ValueError):
                return self._error_response(f"Invalid schema: {schema}", "invalid_schema")
            
            # Use current date if not specified
            if not date_range:
                # Default to yesterday
                yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
                date_range = (yesterday, yesterday)
            
            # Create output directory if it doesn't exist
            os.makedirs(output_path, exist_ok=True)
            
            # Create a unique filename
            filename = f"{symbol}_{dataset}_{schema}_{date_range[0]}_{date_range[1]}.dbn"
            filepath = os.path.join(output_path, filename)
            
            # Download historical data
            metadata = self.historical.batch.historical_batch_download(
                dataset=dataset_enum,
                symbols=[symbol],
                schema=schema_enum,
                start=f"{date_range[0]}T00:00:00",
                end=f"{date_range[1]}T23:59:59",
                path=filepath
            )
            
            return {
                "success": True,
                "symbol": symbol,
                "dataset": dataset,
                "schema": schema,
                "date_range": date_range,
                "filepath": filepath,
                "file_size_bytes": os.path.getsize(filepath),
                "metadata": metadata.to_dict(),
                "message": f"Successfully downloaded data to {filepath}"
            }
                
        except Exception as e:
            logger.error(f"Error downloading historical data: {str(e)}")
            return self._error_response(f"Failed to download historical data: {str(e)}", "api_error")
    
    def get_tape_reading_data(self, symbol: str, dataset: str = "XNAS_ITCH", 
                            date: str = None, limit: int = 100) -> Dict[str, Any]:
        """
        Get combined tape reading data (trades, quotes, size distribution)
        
        Args:
            symbol (str): Symbol to retrieve data for
            dataset (str): Dataset name
            date (str): Date in ISO format (YYYY-MM-DD)
            limit (int): Maximum entries to return
            
        Returns:
            Dict: Tape reading data
        """
        if not self.historical:
            return self._error_response("Databento client not initialized", "authentication_error")
        
        try:
            # Get trades data
            trades_response = self.get_trades(symbol, dataset, date, limit)
            
            if not trades_response.get('success', False):
                return trades_response
            
            trades = trades_response.get('trades', [])
            
            # Get quotes data
            quotes_response = self.get_quotes(symbol, dataset, date, limit)
            
            if not quotes_response.get('success', False):
                return quotes_response
            
            market_data = quotes_response.get('market_data', {})
            quotes = quotes_response.get('quotes', [])
            
            # Calculate size distribution for trades
            size_distribution = {}
            if trades:
                sizes = [t['size'] for t in trades]
                size_distribution = {
                    'min': min(sizes),
                    'max': max(sizes),
                    'avg': sum(sizes) / len(sizes),
                    'median': sorted(sizes)[len(sizes) // 2]
                }
            
            # Calculate trade direction distribution
            buys = sum(1 for t in trades if t.get('is_buyer_maker', False))
            sells = len(trades) - buys
            
            if trades:
                buy_pct = round(buys / len(trades) * 100, 2)
                sell_pct = round(sells / len(trades) * 100, 2)
            else:
                buy_pct = sell_pct = 0
            
            # Calculate VWAP
            if trades:
                vwap = sum(t['price'] * t['size'] for t in trades) / sum(t['size'] for t in trades)
            else:
                vwap = 0
            
            # Merge and return all data
            return {
                "success": True,
                "symbol": symbol,
                "market_data": market_data,
                "trades": trades[:limit],
                "quotes": quotes[:limit],
                "tape_analysis": {
                    "trade_count": len(trades),
                    "size_distribution": size_distribution,
                    "buy_count": buys,
                    "sell_count": sells,
                    "buy_percentage": buy_pct,
                    "sell_percentage": sell_pct,
                    "vwap": vwap,
                },
                "source": "databento_historical"
            }
                
        except Exception as e:
            logger.error(f"Error getting tape reading data: {str(e)}")
            return self._error_response(f"Failed to get tape reading data: {str(e)}", "api_error")
    
    def _error_response(self, message: str, error_type: str, symbol: str = None) -> Dict[str, Any]:
        """Create a standardized error response"""
        return {
            "success": False,
            "error": message,
            "error_type": error_type,
            "symbol": symbol
        }


# Create a singleton instance
databento_advanced = DatabentoAdvanced()