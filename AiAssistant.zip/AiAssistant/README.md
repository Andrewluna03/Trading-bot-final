# AI Trading Analyzer

An advanced AI-powered trading analysis platform that combines intelligent market data processing, machine learning, and psychological support to provide comprehensive trading insights.

## Features

- Real-time market data integration with Databento and Polygon.io APIs
- Advanced WebSocket-based data streaming for market monitoring
- AI-powered market analysis and predictive insights using OpenAI and Anthropic Claude
- Dynamic data processing with comprehensive error handling
- Secure Flask-based backend with modular market monitoring routes
- Enhanced interactive dashboard with engaging UI elements

## Setup

### Prerequisites

- Python 3.11+
- Databento API Key
- Polygon API Key (optional)
- OpenAI API Key (optional, for AI analysis)
- Anthropic API Key (optional, for AI analysis)

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git
   cd YOUR_REPO
   ```

2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Set up environment variables:
   - Create a `.env` file in the root directory
   - Add your API keys:
     ```
     DATABENTO_API_KEY=your_databento_key
     POLYGON_API_KEY=your_polygon_key
     OPENAI_API_KEY=your_openai_key
     ANTHROPIC_API_KEY=your_anthropic_key
     REALTIME_ENABLED=True
     ```

### Running the Application

1. Start the Flask application:
   ```
   python main.py
   ```
   
2. Navigate to `http://localhost:5000` in your web browser to access the dashboard.

## Using the Trading Analyzer

The dashboard provides real-time analysis of market data including:
- Level 2 order book visualization
- Time & Sales data
- AI-powered trading recommendations
- Technical indicators
- Volume profile analysis

## License

This project is licensed under the MIT License - see the LICENSE file for details.